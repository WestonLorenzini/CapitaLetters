package westonlorenzini.capital.init;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.item.Item;
import westonlorenzini.capital.item.ItemBase;

public class ModItems {

	public static final List<Item> ITEMS = new ArrayList<Item>();
	
}
