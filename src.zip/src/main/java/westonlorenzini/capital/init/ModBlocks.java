package westonlorenzini.capital.init;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import westonlorenzini.capital.blocks.BlockA;
import westonlorenzini.capital.blocks.BlockB;
import westonlorenzini.capital.blocks.BlockBase;
import westonlorenzini.capital.blocks.BlockC;
import westonlorenzini.capital.blocks.BlockD;
import westonlorenzini.capital.blocks.BlockE;
import westonlorenzini.capital.blocks.BlockF;
import westonlorenzini.capital.blocks.BlockG;
import westonlorenzini.capital.blocks.BlockH;
import westonlorenzini.capital.blocks.BlockI;
import westonlorenzini.capital.blocks.BlockJ;
import westonlorenzini.capital.blocks.BlockK;
import westonlorenzini.capital.blocks.BlockL;
import westonlorenzini.capital.blocks.BlockM;
import westonlorenzini.capital.blocks.BlockN;
import westonlorenzini.capital.blocks.BlockO;
import westonlorenzini.capital.blocks.BlockP;
import westonlorenzini.capital.blocks.BlockQ;
import westonlorenzini.capital.blocks.BlockR;
import westonlorenzini.capital.blocks.BlockS;
import westonlorenzini.capital.blocks.BlockT;
import westonlorenzini.capital.blocks.BlockU;
import westonlorenzini.capital.blocks.BlockV;
import westonlorenzini.capital.blocks.BlockW;
import westonlorenzini.capital.blocks.BlockX;
import westonlorenzini.capital.blocks.BlockY;
import westonlorenzini.capital.blocks.BlockZ;


public class ModBlocks {
	
	public static final List<Block> BLOCKS = new ArrayList<Block>();
	
	public static final Block A_BLOCK = new BlockA("capital_a");
	public static final Block B_BLOCK = new BlockB("capital_b");
	public static final Block C_BLOCK = new BlockC("capital_c");
	public static final Block D_BLOCK = new BlockD("capital_d");
	public static final Block E_BLOCK = new BlockE("capital_e");
	public static final Block F_BLOCK = new BlockF("capital_f");
	public static final Block G_BLOCK = new BlockG("capital_g");
	public static final Block H_BLOCK = new BlockH("capital_h");
	public static final Block I_BLOCK = new BlockI("capital_i");
	public static final Block J_BLOCK = new BlockJ("capital_j");
	public static final Block K_BLOCK = new BlockK("capital_k");
	public static final Block L_BLOCK = new BlockL("capital_l");
	public static final Block M_BLOCK = new BlockM("capital_m");
	public static final Block N_BLOCK = new BlockN("capital_n");
	public static final Block O_BLOCK = new BlockO("capital_o");
	public static final Block P_BLOCK = new BlockP("capital_p");
	public static final Block Q_BLOCK = new BlockQ("capital_q");
	public static final Block R_BLOCK = new BlockR("capital_r");
	public static final Block S_BLOCK = new BlockS("capital_s");
	public static final Block T_BLOCK = new BlockT("capital_t");
	public static final Block U_BLOCK = new BlockU("capital_u");
	public static final Block V_BLOCK = new BlockV("capital_v");
	public static final Block W_BLOCK = new BlockW("capital_w");
	public static final Block X_BLOCK = new BlockX("capital_x");
	public static final Block Y_BLOCK = new BlockY("capital_y");
	public static final Block Z_BLOCK = new BlockZ("capital_z");


}
