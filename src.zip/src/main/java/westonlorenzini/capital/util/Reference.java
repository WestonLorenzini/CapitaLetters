package westonlorenzini.capital.util;

public class Reference {
	
	public static final String MOD_ID = "capital"; 
	public static final String NAME = "capitaLetters";
	public static final String VERSION = "Alpha 1.0";
	public static final String ACCEPTED_VERSION = "[1.12]";
	public static final String CLIENT_PROXY_CLASS = "westonlorenzini.capital.proxy.ClientProxy";
	public static final String COMMON_PROXY_CLASS = "westonlorenzini.capital.proxy.ClientProxy";


}
